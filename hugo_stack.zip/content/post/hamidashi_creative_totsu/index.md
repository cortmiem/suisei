+++
author = "Cortmiem"
title = "ハミダシクリエイティブ凸"
date = "2023-01-25"
description = "スマッシュヒット作『ハミダシクリエイティブ』ファン待望の続編がついに登場！"
language="ja"
tags = [
    "ACG",
]
categories = [
    "galgame",
]
image = "3530765300.png"

+++

《{{常轨脱离Creative凸:ハミダシクリエイティブ凸}}》是《{{常轨脱离Creative:ハミダシクリエイティブ}}》的Fan Disc。

FD追加了天梨线、各女主的后日谈以及新配角，内容总量有原作的八成。(常轨脱离Creative 2

## 简介

“总之，下一任学生会长就决定是和泉同学！”

因为这句话而得到抽签学生会长勋章的主人公“和泉智宏”，
克服对外研讨会，度过内部瓦解危机，
解决席卷整个校园的大骚动事件后，
身为领导者的实力终于开始有所成长。

今后，智宏和愉快的学生会成员，妹妹“和泉妃爱”和同学“常磐华乃”，
学妹“锦明日海”，前学生会长“镰仓诗樱”，以及最近经常交流互动的“龙闲天梨”，
会度过什么样的日子呢……？

阅读更多：[常轨脱离Creative](https://zh.moegirl.org.cn/%E5%B8%B8%E8%BD%A8%E8%84%B1%E7%A6%BBCreative)，本文引自[萌娘百科](https://zh.moegirl.org.cn)。

## 在 Android 13 上愉快玩耍

> 设备：Pixel 6A, TQ1A.230105.001.A2, Android 13 stock

ハミクリ凸 使用 Artemis 引擎，
在 Android 上可以使用 `tyranor` 或 `Artroid` 进行游玩。

但是 `tyranor 2.0` 在 A13 上会有白屏的问题，
此外该版本对于部分游戏在 Patch 游戏后会出现闪退的现象，
不进行 Patch 有概率能打开。

2.0版本集成的`kirikiri2`在A13上同样闪退。

ハミクリ凸需要2.0前的最近版本才能正常打开。

游玩时请将`*.pfs(.*)`全部改成`root.pfs(.*)`，放在`tyranor/GAMENAME`下。

|                        Tyranor 1.5.7                         |                        ハミクリ凸生肉                        |
| :----------------------------------------------------------: | :----------------------------------------------------------: |
| [hoshimachi](https://hoshimachi.suisei.cloud/Galgame/Helper/Tyranor%201.5.7.apk "Tyranor 1.5.7") | [hoshimachi](https://hoshimachi.suisei.cloud/Galgame/%E3%83%8F%E3%83%9F%E3%83%80%E3%82%B7%E3%82%AF%E3%83%AA%E3%82%A8%E3%82%A4%E3%83%86%E3%82%A3%E3%83%96%E5%87%B8/%E3%83%8F%E3%83%9F%E3%83%80%E3%82%B7%E3%82%AF%E3%83%AA%E3%82%A8%E3%82%A4%E3%83%86%E3%82%A3%E3%83%96%E5%87%B8.zip) |
